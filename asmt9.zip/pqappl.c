#include"pqimpl.h"
void main()
{
	PQ *p;
	int s,ch;
	printf("Enter the size of Heap:");
	scanf("%d",&s);
	p=PQinit(s);
	do
	{
		printf("==========CHOOSE FROM THE FOLLOWING OPTIONS==========\n");		
		printf("1.Insert\n2.Delete\n3.Display\n4.exit\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 :PQinsert(p,getempl());
				break;
			case 2 :PQdelete(p);
				break;
			case 3 :PQdisplay(p,1,0);
				break;
			case 4 :break;
			default:printf("Invalid choice..please choose a valid choice from the above options\n");
		}
	}while(ch!=4);
				
}	

