#include"pqint.h"

PQ* PQinit(int x)
{
	PQ *p;
	empl e;
	strcpy(e.name,"\0");
	e.id=-10;
	e.salary=0;
	p=(PQ*)malloc(sizeof(PQ));
	p->cap=x;
	p->size=0;
	p->a[0]=e;
	return p;
}
void PQinsert(PQ *p,empl x)
{	
	int i;
	if(p->size==p->cap)
	{
		printf("Queue is Full\n");
		return;		
	}
	for(i=++p->size;p->a[i/2].id>x.id;i/=2)
		p->a[i]=p->a[i/2];
	p->a[i]=x;	
}
empl getempl()
{
	empl e;
	printf("Name   : ");
	scanf("%s",e.name);
	printf("Id     : ");
	scanf("%d",&e.id);
	printf("Salary : ");
	scanf("%f",&e.salary);
	return e;
}
void disp(empl e,int tab)
{
	int i;
	for(i=0;i<tab;i++)
	printf("\t");
	printf("***************\n");
	for(i=0;i<tab;i++)
	printf("\t");
	printf("Name   : %s\n",e.name);
	for(i=0;i<tab;i++)
	printf("\t");
	printf("Id     : %d\n",e.id);
	for(i=0;i<tab;i++)
	printf("\t");
	printf("Salary : %f\n",e.salary);
	for(i=0;i<tab;i++)
	printf("\t");
	printf("***************\n");	
}
void PQdelete(PQ *p)
{	
	if(p->size==0)
	{
		printf("Heap is Empty\n");
		return;	
	}
	int i,child;
	empl minelement, lastelement;
	minelement=p->a[1];
	lastelement=p->a[p->size--];
	for(i=1;(i *2)<=p->size;i=child)
	{
	child=i*2;
	if(p->a[child+1].salary < p->a[child].salary)
		child++;
	if(lastelement.salary> p->a[child].salary)
		p->a[i]=p->a[child];
	else
		break;
	}
	p->a[i]=lastelement;
	printf("THE FOLLOWING RECORD HAS BEEN DELETED!!!\n");
	disp(minelement,0);
}
void PQdisplay(PQ *p,int index,int tab)
{
	int i;
	
	if(index<=p->size)
	{
		disp(p->a[index],tab);
		printf("\n");
		if(index*2<=p->size)		
		PQdisplay(p,index*2,tab+1);
		if(index*2+1<=p->size)
		PQdisplay(p,index*2+1,tab+1);
	}
}
