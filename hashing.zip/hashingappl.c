#include<stdio.h>
#include<stdlib.h>
#include"hashingimpl.h"

void main()
{
  struct hash_table *H;
  H=(struct hash_table*)malloc(sizeof(struct hash_table));
  init(H,10);
  int choice=0;
  int num,key;
 while(choice!=4)
  {
  
         printf("\n*************MAIN MENU************\n");
         printf("\n1.INSERT\n2.SEARCH\n3.DISPLAY\n4.EXIT\n");
         printf("\nEnter your choice:");
         scanf("%d",&choice);
         switch(choice)
            {
              case 1: printf("Enter the number to be inserted:");
                      scanf("%d",&num);
                      insert(H,num);
                      break;
              case 2: printf("Enter the number to be searched:");
                      scanf("%d",&key);
                      search(H,key);
                      break;
              case 3: display(H);
                      break;
              case 4: break;
            }
    }
}
    
/*
cs1175@jtl-26:~/Assignment13$ gcc hashingappl.c -o s
cs1175@jtl-26:~/Assignment13$ ./s

*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:41

 THE NODE 41 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:31

 THE NODE 31 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:21

 THE NODE 21 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:11

 THE NODE 11 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:67

 THE NODE 67 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:98

 THE NODE 98 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:23

 THE NODE 23 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:45

 THE NODE 45 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:62

 THE NODE 62 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:34

 THE NODE 34 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:78

 THE NODE 78 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:94

 THE NODE 94 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:69

 THE NODE 69 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:50

 THE NODE 50 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:8

 THE NODE 8 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:1
Enter the number to be inserted:4

 THE NODE 4 IS INSERTED
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:3
>>>>>HASH TABLE<<<<<
 NODE0 => 50
 NODE1 => 11=> 21=> 31=> 41
 NODE2 => 62
 NODE3 => 23
 NODE4 => 4=> 94=> 34
 NODE5 => 45
 NODE6 
 NODE7 => 67
 NODE8 => 8=> 78=> 98
 NODE9 => 69
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:2
Enter the number to be searched:50

 THE KEY 50 IS FOUND AT NODE 0 

*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:2
Enter the number to be searched:26
THE KEY IS NOT FOUND
*************MAIN MENU************

1.INSERT
2.SEARCH
3.DISPLAY
4.EXIT

Enter your choice:4*/

