#include<stdlib.h>
#include<stdio.h>
struct node
{
  int data;
  struct node *next;
};
struct hash_table
{
  int size;
  struct node *list[100];
};

void init(struct hash_table *H, int size)
{
  int i;
  H->size=size;
  for(i=0;i<H->size;i++)
   {
     H->list[i]=(struct node*)malloc(sizeof(struct node));
     H->list[i]->next=NULL;
   }
}

void insert(struct hash_table *H,int x)
{
   int h;
   struct node *temp;
   h=x%10;
   temp=(struct node*)malloc(sizeof(struct node));
   temp->data=x;
   temp->next=H->list[h]->next;
   H->list[h]->next=temp;
   printf("\n THE NODE %d IS INSERTED",temp->data);
}

void search(struct hash_table *H,int key)
{
  struct node *temp;
  int h;
  h=key%10;
  temp=H->list[h]->next;
  while(temp!=NULL)
   {
    if(temp->data==key){
       printf("\n THE KEY %d IS FOUND AT NODE %d ",temp->data,h);
       break;
      } 
       temp=temp->next;
   }
  if(temp==NULL)
       printf("THE KEY IS NOT FOUND");
}

void display(struct hash_table *H)
{
   int h=0;
   
  struct node *temp;
    
  printf(">>>>>HASH TABLE<<<<<");
  for( int i=0;i<H->size;i++)
   {
       temp=H->list[h]->next;
       h++;
       printf("\n NODE%d ", i);
	while(temp!=NULL)
		{
			printf("=> %d",temp->data);
			temp=temp->next;
		}
	}
}

