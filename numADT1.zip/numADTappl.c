#include <stdio.h>
#include"numADTimpl.h"
void main()
{
	numADT *n;
	int s,ch;
	printf("Enter the size of array:");
	scanf("%d",&s);
	n=init(s);
	do
	{
		printf("==========CHOOSE FROM THE FOLLOWING OPTIONS==========\n");		
		printf("1.Insert\n2.Selection sort\n3.Shell sort\n4.Display\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 :{
					int i;
					int a[s];
					printf("ENTER THE NUMBERS:");
					for(i=0;i<s;i++)
					{
						scanf("%d",&a[i]);
					}
					insert(n,a,s);
					
				break;}
			case 2 :{
					selection_sort(n,s);
				break;}
			case 3 :{
					shell_sort(n,s);
				break;}
			case 4 :{	display(n,s);
					break;}
			default:printf("Invalid choice..please choose a valid choice from the above options\n");
		}
	}while(ch!=4);
				
}	
