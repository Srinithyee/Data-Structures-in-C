#include "numADTint.h"
#include <stdlib.h>
numADT* init(int x)
{
	numADT *n;
	n=(numADT*)malloc(sizeof(numADT));
	n->size=x;
	return n;
}

void insert( numADT *n,int *var1, int len)
{

    for(int x=0; x<len; x++)
    {
        n->arr[x]=*var1;
        var1++;
    }
}

void selection_sort(numADT *n,int l)
{
	int c,position,swap,d,x;
	for (c = 0; c < (l - 1); c++)
  	{
    	position = c;
    	for (d = c + 1; d < l; d++)
    	{
      		if (n->arr[position] > n->arr[d])
        	position = d;
    	}
    	if (position != c)
    	{
      		swap = n->arr[c];
      		n->arr[c] = n->arr[position];
      		n->arr[position] = swap;
    	}
 	}
	printf("Sorted list in ascending order:\n");
 	for (x= 0; x < l; x++){
    printf("%d\n", n->arr[x]);}
 

}

void shell_sort(numADT *n,int l)
{
	int i, j, k, tmp,c;
	for (i = l / 2; i > 0; i = i / 2)
	{
        for (j = i; j < l; j++)
        {
            for(k = j - i; k >= 0; k = k - i)
		{
                if (n->arr[k+i] >= n->arr[k])
                    break;
                else
                {
                    tmp = n->arr[k];
                    n->arr[k] = n->arr[k+i];
                    n->arr[k+i] = tmp;
                }
           	}
        }
    	}
	printf("Sorted list in ascending order:\n");
	for (c = 0; c < l; c++)
	printf("%d\n", n->arr[c]); 
  
}
	
void display(numADT *n,int l)
{
	int i;
	for(i=0;i<l;i++)
	{
		printf("%d \n",n->arr[i]);
	}
}


/*cs1166@jtl-25:~/Desktop/asm15$ gcc -o a numADTappl.c
cs1166@jtl-25:~/Desktop/asm15$ ./a
Enter the size of array:5
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.Selection sort
3.Shell sort
4.Display
1
ENTER THE NUMBERS:45
67
89
23
14
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.Selection sort
3.Shell sort
4.Display
2
Sorted list in ascending order:
14
23
45
67
89
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.Selection sort
3.Shell sort
4.Display
3
Sorted list in ascending order:
14
23
45
67
89
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.Selection sort
3.Shell sort
4.Display
4
14 
23 
45 
67 
89 
*/
