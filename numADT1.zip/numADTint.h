typedef struct{
	int arr[100];
	int size;
}numADT;

