#include <stdio.h>
#include"numADTimpl.h"
void main()
{
	numADT *n;
	int s,ch;
	printf("Enter the size of array:");
	scanf("%d",&s);
	n=init(s);
	do
	{
		printf("==========CHOOSE FROM THE FOLLOWING OPTIONS==========\n");		
		printf("1.Insert\n2.linear search\n3.binary serach\n4.display\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1 :{
					int i;
					int a[s];
					for(i=0;i<s;i++)
					{
						scanf("%d",&a[i]);
					}
					insert(n,a,s);
					
				break;}
			case 2 :{
					int m;
					printf("ENTER THE NUMBER TO BE SEARCHED");
					scanf("%d",&m); 
					linear_search(n,m,s);
				break;}
			case 3 :{
					int m;
					printf("ENTER THE NUMBER TO BE SEARCHED");
					scanf("%d",&m); 
					binary_search(n,m,s);
				break;}
			case 4 :{	display(n,s);
					break;}
			default:printf("Invalid choice..please choose a valid choice from the above options\n");
		}
	}while(ch!=4);
				
}	

/*cs1166@jtl-25:~/Desktop/asm14$ gcc -o a numADTappl.c
cs1166@jtl-25:~/Desktop/asm14$ ./a
Enter the size of array:3
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.linear search
3.binary serach
4.display
1
23
14
57
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.linear search
3.binary serach
4.display
2
ENTER THE NUMBER TO BE SEARCHED23
Element has been found at 0th position.
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.linear search
3.binary serach
4.display
3
ENTER THE NUMBER TO BE SEARCHED14
14 found at location 2.
==========CHOOSE FROM THE FOLLOWING OPTIONS==========
1.Insert
2.linear search
3.binary serach
4.display
4
23 
14 
57 
*/
