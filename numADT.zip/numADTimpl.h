#include "numADTint.h"
#include <stdlib.h>
numADT* init(int x)
{
	numADT *n;
	n=(numADT*)malloc(sizeof(numADT));
	n->size=x;
	return n;
}

void insert( numADT *n,int *var1, int len)
{

    for(int x=0; x<len; x++)
    {
        n->arr[x]=*var1;
        var1++;
    }
}

void linear_search(numADT *n,int key,int l)
{
	int i;
	for(i=0;i<l;i++)
	{
		if(n->arr[i]==key)
		printf("Element has been found at %dth position.\n",i);
		break;
	}
	if(i==l)
	printf("ELEMENT not found");
}

void binary_search(numADT *n,int key,int l)
{
	int first,last,middle;
   first = 0;
   last = l- 1;
   middle = (first+last)/2;
 
   while (first <= last) {
      if (n->arr[middle] < key)
         first = middle + 1;    
      else if (n->arr[middle] == key) {
         printf("%d found at location %d.\n", key, middle+1);
         break;
      }
      else
         last = middle - 1;
 
      middle = (first + last)/2;
   }
   if (first > last)
      printf("Not found! %d isn't present in the list.\n", key);
  
}
	
void display(numADT *n,int l)
{
	int i;
	for(i=0;i<l;i++)
	{
		printf("%d \n",n->arr[i]);
	}
}

