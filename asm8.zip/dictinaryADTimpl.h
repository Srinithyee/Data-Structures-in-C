#include "dictionaryADTint.h"
#define max(a,b) (a>b?a:b)

void initialise(dictionaryADT *p)
{
	p=(dictionaryADT *)malloc(sizeof(dictionaryADT));
	p->r=p->l=NULL;
	p->ht=0;
}

dictionaryADT* find(dictionaryADT *p,words x)
{
    if(p==NULL)
    {
        return NULL;
    }
    if(strcmp(p->p1.word,x.word)==0)
    {
        return p;
    }
    if(strcmp(p->p1.word,x.word)>0)
	{
		return find(p->l,x);
		
	}
	else if(strcmp(p->p1.word,x.word)<0)
	{
		return find(p->r,x);
		
	}

}

int height(dictionaryADT *p)
{
	if(p==NULL)
	{
		return -1;
	}
	else
		return p->ht;
}

dictionaryADT* SRL(dictionaryADT *k2)
{
	dictionaryADT *k1;
	k1=k2->l;
	k2->l=k1->r;
	k1->r=k2;

	k2->ht=max(height(k2->l),height(k2->r))+1;
	k1->ht=max(height(k1->l),k2->ht)+1;
	return k1;
}

dictionaryADT* SRR(dictionaryADT *k2)
{
	dictionaryADT *k1;
	k1=k2->r;
	k2->r=k1->l;
	k1->l=k2;

	k2->ht=max(height(k2->l),height(k2->r))+1;
	k1->ht=max(height(k1->r),k2->ht)+1;
	return k1;
}

dictionaryADT* DRL(dictionaryADT *k3)
{
	k3->l=SRR(k3->l);
	return SRL(k3);
}

dictionaryADT* DRR(dictionaryADT *k3)
{
	k3->r=SRL(k3->r);
	return SRR(k3);
}

dictionaryADT* insert(dictionaryADT *p,words x)
{
	int hdiff;
	if(p==NULL)
	{
		p=(dictionaryADT *)malloc(sizeof(dictionaryADT));
		strcpy(p->p1.word,x.word);
		strcpy(p->p1.meaning,x.meaning);
		p->l=p->r=NULL;
		p->ht=0;
	}
	else if(strcmp(p->p1.word,x.word)>0)
	{
		p->l=insert(p->l,x);
		hdiff=abs(height(p->l)-height(p->r));
		if(hdiff==2)
		{
			//printf("Rotating\n");
			if(strcmp(p->l->p1.word,x.word)>0)
			p=SRL(p);
			else
			p=DRL(p);
		}
		p->ht=max(height(p->l),height(p->r))+1;
		//printf("%d\n",hdiff);
	}
	else if(strcmp(p->p1.word,x.word)<0)
	{
		p->r=insert(p->r,x);

		hdiff=abs(height(p->l)-height(p->r));
		if(hdiff==2)
		{
			//printf("Rotating\n");
			if(strcmp(p->r->p1.word,x.word)<0)
			p=SRR(p);
			else
			p=DRR(p);
		}
		p->ht=max(height(p->l),height(p->r))+1;
	}
	return p;
}

void disptree(dictionaryADT *p,int tab)
{
	int i;
	printf("\n");
	for(i=1;i<=tab;i++)
		printf("\t");
	printf("WORD:%s||MEANING:%s\n",p->p1.meaning,p->p1.word);
	
	if(p->l!=NULL)
		disptree(p->l,tab+1);
	
	
	if(p->r!=NULL)
		disptree(p->r,tab+1);
		
}
