
#include<stdio.h>
#include<string.h>
#include "dictinaryADTimpl.h"

void main()
{
	dictionaryADT *p,*search;
	initialise(p);
	words x;
	int ch,c,i,j;
	int n;
	do
	{
		printf("\n\n==========Choose from the following options==========\n\n1.INSERT\n2.DISPLAY\n3.SEARCH\n\n");
		scanf("%d",&c);
		switch(c)
		{
			case 1:
			{
				printf("Enter the number of words to be inserted:");
				scanf("%d",&n);
				for(i=0;i<n;i++)
				{
					printf("\nEnter the word to be inserted :");
					scanf("%s",x.word);
					printf("\nEnter the meaning of the word:");
					scanf("%s",x.meaning);
					p=insert(p,x);
				}
				break;
			}
			case 2:
			{
				disptree(p,0);
				break;
			}
			case 3:
			{
				printf("Enter the word which has to be searched:");
				scanf("%s",x.word);
				search=find(p,x);
				if(search==NULL)
				{
					printf("The word is not present in the dictionary!!!");
				}
				else{
				printf("WORD:%s\nMEANING:%s",search->p1.word,search->p1.meaning);
				}
				break;
			}
		}
		printf("\n\nDo you want to continue\n1.YES\n2.NO\n");
		scanf("%d",&ch);
	}while(ch==1);
}
