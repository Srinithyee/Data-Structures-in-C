#include<stdio.h>
#include<stdlib.h>
#include<math.h>


typedef struct
{
	char word[20];
	char meaning[100];
}words;

typedef struct dictionaryADT
{
	words p1;
	struct dictionaryADT *l;
	struct dictionaryADT *r;
	int ht;
}dictionaryADT;


